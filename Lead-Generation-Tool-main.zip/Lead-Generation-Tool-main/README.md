# Lead-Generation-Tool

AI-powered lead generation web app built with Tailwind, TypeScript, and Vite.

## Setup

npm install

npm run dev

## Build
npm run build

# Features
Scalable UI
Tailwind + Vite
Lead scoring ready


For signing up, make sure to enter a password with 8 characters
